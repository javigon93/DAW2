// export class Trabajador {
//   public id: number;
//   public votos:number;



export interface Trabajador{

   id: number;
   votos:number;

   nombre:string;
   cargo:string;
   foto:string;


}
