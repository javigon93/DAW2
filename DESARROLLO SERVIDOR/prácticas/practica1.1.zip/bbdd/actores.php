<?php

return array(
    array(
        'id' => 1,
        'nombre' => 'Marlon Brando',
        'anyo' => 1924,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 2,
        'nombre' => 'Al pacino',
        'anyo' => 1940,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 3,
        'nombre' => 'Robert Duvall',
        'anyo' => 1931,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 4,
        'nombre' => 'James Caan',
        'anyo' => 1940,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 5,
        'nombre' => 'Diane Keaton',
        'anyo' => 1946,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 6,
        'nombre' => 'Robert de Niro',
        'anyo' => 1943,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 7,
        'nombre' => 'Kirk Douglas',
        'anyo' => 1916,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 8,
        'nombre' => 'Ralph Meeker',
        'anyo' => 1920,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 9,
        'nombre' => 'Adolphe Menjou',
        'anyo' => 1890,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 10,
        'nombre' => 'Jack Lemmon',
        'anyo' => 1925,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 11,
        'nombre' => 'Walter Matthau',
        'anyo' => 1920,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 12,
        'nombre' => 'Susan Sarandon',
        'anyo' => 1946,
        'pais' => 'Estados unidos'
    ),
);