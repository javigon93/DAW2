<?php

return array(
    array(
        'id_pelicula' => 1,
        'id_actor' => 1
    ),
    array(
        'id_pelicula' => 1,
        'id_actor' => 2
    ),
    array(
        'id_pelicula' => 1,
        'id_actor' => 3
    ),
    array(
        'id_pelicula' => 1,
        'id_actor' => 4
    ),
    array(
        'id_pelicula' => 1,
        'id_actor' => 5
    ),
    array(
        'id_pelicula' => 2,
        'id_actor' => 1
    ),
    array(
        'id_pelicula' => 2,
        'id_actor' => 2
    ),
    array(
        'id_pelicula' => 2,
        'id_actor' => 3
    ),
    array(
        'id_pelicula' => 2,
        'id_actor' => 5
    ),
    array(
        'id_pelicula' => 2,
        'id_actor' => 6
    ),
    array(
        'id_pelicula' => 3,
        'id_actor' => 7
    ),
    array(
        'id_pelicula' => 3,
        'id_actor' => 8
    ),
    array(
        'id_pelicula' => 3,
        'id_actor' => 9
    ),
    array(
        'id_pelicula' => 4,
        'id_actor' => 10
    ),
    array(
        'id_pelicula' => 4,
        'id_actor' => 11
    ),
    array(
        'id_pelicula' => 4,
        'id_actor' => 12
    ),

);