<?php

return array(
    array(
        'id' => 1,
        'nombre' => 'Francis Ford Coppola',
        'anyo' => 1939,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 2,
        'nombre' => 'Stanley Kubrick',
        'anyo' => 1928,
        'pais' => 'Estados unidos'
    ),
    array(
        'id' => 3,
        'nombre' => 'Billy Wilder',
        'anyo' => 1906,
        'pais' => 'Polonia'
    ),
);