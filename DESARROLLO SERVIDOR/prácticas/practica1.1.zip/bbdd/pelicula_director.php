<?php

return array(
    array(
        'id_pelicula' => 1,
        'id_director' => 1
    ),
    array(
        'id_pelicula' => 2,
        'id_director' => 1
    ),
    array(
        'id_pelicula' => 3,
        'id_director' => 2
    ),
    array(
        'id_pelicula' => 4,
        'id_director' => 3
    ),
);