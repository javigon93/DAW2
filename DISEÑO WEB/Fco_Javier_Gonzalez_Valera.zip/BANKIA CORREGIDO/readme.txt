Ejercicio Bankia, actualizado (al menos intentado) a lo dado en las últimas clases.

He simplificado la estructura de archivos relativa a despliegue, en principio, por comodidad (ya que es una actividad donde muchas carpetas quedan vacías,
no se aprovecha la estructura). 
La estructura de carpetas de scss se respeta.

